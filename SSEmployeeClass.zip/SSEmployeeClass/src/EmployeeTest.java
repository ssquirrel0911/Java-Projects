//Samantha Squirrel
//CSC 142 
//Chapter 3 Programming challenge 1 Due 2-7-2019

//Employee Class Demo

import java.util.Scanner;

/**
 * This program runs a test of the Employee class

 */

public class EmployeeTest {

	static Scanner keyboard = new Scanner(System.in);

	private final static int MAX_EMPLOYEES = 3;

	private static Employee employees[] = new Employee[MAX_EMPLOYEES];

	private static void createEmployee(int num) {
		String name;
		int id;
		String dept;
		String pos;
		System.out.print("Enter the Employee's Name: ");
		name = keyboard.next();
		System.out.print("Enter the Employee's IDNumber: ");
		id = keyboard.nextInt();
		System.out.print("Enter the Employee's Department: ");
		dept = keyboard.next();
		System.out.print("Enter the Employee's Poisition: ");
		pos = keyboard.next();
		System.out.println();
		employees[num] = new Employee(name,id,dept,pos);
	}

	public static void main(String[] args) {
		for(int i=0; i< MAX_EMPLOYEES; i++) {
			createEmployee(i);
		}      
		System.out.println("Here is the data of the Employees:");
		for(int i=0; i< MAX_EMPLOYEES; i++) {
			display(i);
		}  
	}

	public static void display(int num) {
		System.out.println();
		System.out.println("Employee #: "+num+1);
		System.out.println("Name: " + employees[num].getName());
		System.out.println("IdNumber: " + employees[num].getIdNumber());
		System.out.println("Department: " + employees[num].getDepartment());
		System.out.println("Position: " + employees[num].getPosition());
	}
}