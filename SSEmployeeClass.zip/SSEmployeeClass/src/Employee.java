//Samantha Squirrel
//CSC 142 
//Chapter 3 Programming challenge 1 Due 2-7-2019

//Employee Class

public class Employee
{
   //Fields
   private String name; 
   private int idNumber;
   private String department;
   private String position;
   
   /**
   * The constructor accepts arguments for
   * the employee's Name, ID Number, Department,
   * and position
   */
   
   public Employee(String n, int intId, String dept, String posi)
   {
      name = n;
      idNumber = intId;
      department = dept;
      position = posi;
   }
   
   /**
   * The setName method accepts an argument for
   * the Employee's name.
   */
   
   public void setName(String n)
   {
      name = n;
   }

   /**
   * The setIdNumber method accepts an argument for
   * the Employee's idNumber.
   */
   
   public void setIdNumber(int intId)
   {
      idNumber = intId; 
   }
   
   /**
   * The setDepartment method accepts an argument for
   * the Employee's department.
   */
   
   public void setDepartment(String dept)
   {
      department = dept;
   }
   
   /**
   * The setPosition method accepts an argument for
   * the Employee's name.
   */
   
   public void setPosition(String posi)
   {
      position = posi;
   }
   
   /**
   * The getName method returns the name of
   * the Employee's name.
   */
   
   public String getName()
   {
      return name;
   }
   
   /**
   * The getIdNumber method returns the number of
   * the Employee's IDNumber.
   */
   
   public int getIdNumber()
   {
      return idNumber;
   }
   
   /**
   * The getDaprtment method returns the name of
   * the Employee's deparment.
   */
   
   public String getDepartment()
   {
      return department;
   }
   
   /**
   * The getPosition method returns the name of
   * the Employee's position.
   */
   
   public String getPosition()
   {
      return position;
   }

}
   
   