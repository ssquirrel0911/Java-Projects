//Samantha Squirrel
//CSC142
//Abstract class Programming exercise 1
//Assignment due 4-30-2019


import java.util.ArrayList;
import java.util.List;

public class SSBookArray {
    static List<SSBookClass> booksList = new ArrayList<SSBookClass>();
    public static void main(String[] args){
        SSBookClass books;
        
        books=new SSFiction("The Sword in the Stone");
        
        booksList.add(books);
        
        books = new SSNonFiction("Once upon a time");
        
        booksList.add(books);
        
        books = new SSFiction("Fictional Java book");
        
        booksList.add(books);
        
        books = new SSFiction("Whinnie the poo");
        
        booksList.add(books);
        
        books = new SSFiction("The Legend of Zelda");
        }

}
