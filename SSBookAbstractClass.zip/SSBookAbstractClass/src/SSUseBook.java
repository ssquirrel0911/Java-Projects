//Samantha Squirrel
//CSC142
//Abstract class Programming exercise 1
//Assignment due 4-30-2019

public class SSUseBook {
    public static void main(String[] args){
    	
        SSBookClass books;
        
        books = new SSFiction("The Sword in the stone");
        
        System.out.println(books.getTitle());
        
        books = new SSNonFiction("Once upon a time...");
        
        System.out.println(books);
        }

}
