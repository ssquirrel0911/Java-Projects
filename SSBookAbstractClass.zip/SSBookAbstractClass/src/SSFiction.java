//Samantha Squirrel
//CSC142
//Abstract class Programming exercise 1
//Assignment due 4-30-2019

public class Fiction extends SSBookClass {
	   public Fiction(String title) {
	        super(title);
	        setPrice();
	    }
	    
	    public void setPrice(){
	        super.bookPrice=24.99;
	}
}
