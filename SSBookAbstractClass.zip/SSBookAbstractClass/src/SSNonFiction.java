//Samantha Squirrel
//CSC142
//Abstract class Programming exercise 1
//Assignment due 4-30-2019

public class NonFiction extends SSBookClass {
    public NonFiction(String title) {
        super(title);
        setPrice();
    }
    
    public void setPrice(){
        super.bookPrice=37.99;
}
}
