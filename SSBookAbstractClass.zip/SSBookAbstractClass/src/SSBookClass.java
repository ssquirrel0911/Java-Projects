//Samantha Squirrel
//CSC142
//Abstract class Programming exercise 1
//Assignment due 4-30-2019
public abstract class SSBookClass {
	
    String bookTitle; 
    double bookPrice;
    
    public BookClass(String title){
        bookTitle=title;
    }
    
    public String getTitle(){
        return bookTitle;
    }
    
    public double getPrice(){
        return bookPrice;
    }
    
public abstract void setPrice();
}
