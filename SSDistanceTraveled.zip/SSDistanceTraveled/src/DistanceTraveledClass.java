//Samantha Squirrel
//CSC 142 
//Assignment due 2-19-2019
//Chapter 5 Programming Exercise 2

//Distance Traveled Class
import java.util.Scanner;


public class DistanceTraveledClass {
	public static void main(String[] args) {
		double distanceTraveled;
		int timeTraveled;
	}
	private int timeTraveled = 0;
	private double speedOfVehicle = 0;

	public double DistanceTraveledClass(double speed, int time) {
		double speedOfVehicle = speed;
		int timeTraveled = time;
		double distanceTraveled;
		return distanceTraveled = speed * time;
	}
		
	public double getDistance() {
	int distanceTraveled = (int) (speedOfVehicle * timeTraveled);
	return distanceTraveled;
	}
}
