import java.util.Scanner;
import java.io.*;

//Samantha Squirrel
//CSC 142 
//Assignment due 2-19-2019
//Chapter 5 Programming Exercise 2

//Distance Traveled Driver

public class SSDistanceTraveledDriver {
	
	public static void main(String[] args) throws IOException {
		
		String filename; // File name
		
		//Create Scanner object for input
		Scanner keyboard = new Scanner(System.in);
		double speedOfVehicle = -1;
		int timeTraveled = 0;
		double distanceTraveled;
		int accumulate = 0;
		int hour = 1;
		String filename;
		String distanceTravel;
		
		//Get the file name
		System.out.println("Enter the filename: ");
		filename = keyboard.nextLine();
		
		//Open the file
		PrintWriter outputFile = new PrinteWriter(filename);
		
		
		while (speedOfVehicle < 0) {
			//User input for the speed of their vehicle
			System.out.println("Enter the speed your vehicle is going: ");
			speedOfVehicle = keyboard.nextDouble();
		}
		
		while(timeTraveled < 1) {
			System.out.println("Enter the time traveled in your vehicle: ");
			timeTraveled = keyboard.nextInt();
		}
		
		//Get data and write it to the file
		while(hour <= timmeTraveled)
		{
			distanceTravel = keyboard.nextLine();
			distnaceTraveled = speed * hour;
			outputFile.println(distanceTravel)
		}
		
		//Close the file
		outputFile.close();
	}
}
