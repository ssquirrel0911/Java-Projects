//Samantha Squirrel
//CSC 142 
//Chapter 3 Programming challenge 2 Due 2-7-2019

//Car Class

public class Car {
   //Fields
   private int yearModel; 
   private String make;
   private int speed;
   
   public int getYearModel() {
	   return yearModel;
   }
   
   public String getMake() {
	   return make;
   }
   
   public int getSpeed() {
	   return speed;
   }
   
   public void accelarate() {
	   speed += 5;
   }
   
   public void brake() {
	   speed -= 5;
   }
   
   public CarClass(int ym, String makeType) {
	   yearModel = ym;
	   make = makeType;
	   speed = 0;
   }
}
