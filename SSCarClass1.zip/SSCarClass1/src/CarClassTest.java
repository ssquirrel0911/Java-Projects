//Samantha Squirrel
//CSC 142 
//Chapter 3 Programming challenge 2 Due 2-7-2019

//Car Class Test

public class CarClassTest {
	public static void main(String[] args) {
		Car car1 = new Car(2010, "Ifiniti");
		
		System.out.println("Putting some force in accelerating: ");
		for(int seconds = 1; seconds <=5; seconds ++) {
			car1.accelarate();
			System.out.println("The current speed of the " + car1.getYearModel() + " " + car1.getMake() + " is " +
			car1.getSpeed() + " km/h");
		}
		
		System.out.println("Taking foot of the accelartion: ");
		for(int seconds = 1; seconds <= 5; seconds++) {
			car1.brake();
			System.out.println("The current speed of the " + car1.getYearModel() + " " + car1.getMake() + " is " +
			car1.getSpeed() + " km/h");
		}
	}

}
