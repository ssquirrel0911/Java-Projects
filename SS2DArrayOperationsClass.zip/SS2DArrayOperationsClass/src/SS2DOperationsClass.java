//Samantha Squirrel
//CSC 142
//Programming Challenges 17
//Assingment due 4-4-2019

public class SS2DOperationsClass {

	
	public static double getTotal(double[][] array) { 
		  double total = 0; 
		 
		  for (int row = 0; row < array.length; row++) { 
		   for (int col = 0; col < array[row].length; col++) { 
		    total += array[row][col]; 
		   } 
		  } 
		 
		  return total; 
		 } 
		 
		 public static double getAverage(double[][] array) { 
		  return getTotal(array) / getElementCount(array); 
		 } 
		 
		 public static double getRowTotal(double[][] array, int row) { 
		  double total = 0; 
		 
		  for (int col = 0; col < array[row].length; col++) { 
		   total += array[row][col]; 
		  } 
		 
		  return total; 
		 } 
		 
		 public static double getColumnTotal(double[][] array, int col) { 
		  double total = 0; 
		 
		  for (int row = 0; row < array.length; row++) { 
		   total += array[row][col]; 
		  } 
		 
		  return total; 
		 } 
		 
		 public static double getHighestInRow(double[][] array, int row) { 
		  double highest = array[row][0]; 
		 
		  for (int col = 1; col < array[row].length; col++) { 
		   if (array[row][col] > highest) { 
		    highest = array[row][col]; 
		   } 
		  } 
		  return highest; 
		 } 
		 
		 public static double getLowestInRow(double[][] array, int row) { 
		  double lowest = array[row][0]; 
		 
		  for (int col = 1; col < array[row].length; col++) { 
		   if (array[row][col] < lowest) { 
		    lowest = array[row][col]; 
		   } 
		  } 
		  return lowest; 
		 } 
		 
		 public static int getElementCount(double[][] array) { 
		  int count = 0; 
		 
		  for (int row = 0; row < array.length; row++) { 
		   count += array[row].length; 
		  } 
		  return count; 
		 } 
		 
		 public static void main(String[] args) { 
		 
		  double[][] studentTestScores = { { 100.0, 50.00, 40.00, 99.8 }, 
		    { 110.5, 50.00, 78.90, 90.80 } }; 
		 
		  // Process the double array. 
		  System.out.println("Total : " + getTotal(studentTestScores)); 
		  System.out.println("Average : " + getAverage(studentTestScores)); 
		 
		  System.out.println("Total of row 0 : " 
		    + getRowTotal(studentTestScores, 0)); 
		  System.out.println("Total of row 1 : " 
		    + getRowTotal(studentTestScores, 1)); 
		 
		  System.out.println("Total of col 0 : " 
		    + getColumnTotal(studentTestScores, 0)); 
		  System.out.println("Total of col 1 : " 
		    + getColumnTotal(studentTestScores, 2)); 
		 
		  System.out.println("Highest in row 0 : " 
		    + getHighestInRow(studentTestScores, 0)); 
		  System.out.println("Highest in row 1 : " 
		    + getHighestInRow(studentTestScores, 1)); 
		 
		  System.out.println("Lowest in row 0 : " 
		    + getLowestInRow(studentTestScores, 0)); 
		  System.out.println("Lowest in row 1 : " 
		    + getLowestInRow(studentTestScores, 1)); 
		 
		 } 
		 
}

