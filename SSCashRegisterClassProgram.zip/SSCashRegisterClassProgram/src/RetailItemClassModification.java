
public class RetailItemClassModification {
	   private String description;  
	   private int itemNumber; 
	   private CostData cost;


	   public RetailItemClassModification(String desc, int itemNum, 
	                     double wholesale, double retail)
	   {
	      description = desc;
	      itemNumber = itemNum;
	      cost = new CostData(wholesale, retail);
	   }
	   
	   public double getSale() {
	    	  return cost.wholesale;
	    	  
	   }
	   
	   public double getRetail() {
		   return cost.retail;
		   
	   }

	   public String toString()
	   {
	      String str;
	      

	      str = String.format("Description: %s\n" +
	                          "Item Number: %d\n" +
	                          "Wholesale Cost: $%,.2f\n" +
	                          "Retail Price: $%,.2f\n",
	                          description, itemNumber,
	                          cost.wholesale, cost.retail);
	      return str;
	   }
	   



	   private class CostData {
	      public double wholesale,  
	                    retail;

	      public CostData(double w, double r) {
	         wholesale = w;
	         retail = r;
	      }
	   }

}
