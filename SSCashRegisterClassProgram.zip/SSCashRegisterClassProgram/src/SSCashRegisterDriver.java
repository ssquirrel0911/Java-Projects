
public class SSCashRegisterDriver {
	
	public static void main(String[] args) {
		RetailItemClassModification cr = new RetailItemClassModification("Food", 5, 10.0, 20.0);
		
		System.out.print(cr);
	}

}
