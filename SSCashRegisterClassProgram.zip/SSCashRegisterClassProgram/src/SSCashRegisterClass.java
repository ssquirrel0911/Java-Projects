
public class SSCashRegisterClass {
	
	private final double TAX_RATE = 0.06;
	private double retail;
	private int quantity;
	private int subtotal; 
	
	public SSCashRegisterClass(RetailItemClassModification item, int q) {
		retail = item.getRetail();
		quantity = q;
		
	}
	
	public double getSubtotal() {
		double subtotal = retail * quantity;
		return subtotal;
		}
	
	public double getTax() {
		double tax = TAX_RATE*subtotal;
		return tax;
		}
	
	public double getTotal(double tax, double subtoal) {
		double total = tax + subtotal;
		return total;
		
	}

}
