//Samantha Squirrel
//CSC 142
//Programming Challenges 11
//Assingment due 4-4-2019

public class SSArrayOperationsClass {
	
	public static double getTotal(double[] numbers) {
		double total = 0;
		
		for(int currentNumbersIndex = 0; currentNumbersIndex < numbers.length; currentNumbersIndex++) {
			total = total + numbers[currentNumbersIndex];
		}
		
		return total;
	}
	
	public static double getAverage(double[] numbers ) {
		double numbersTotal = getTotal(numbers);
		int numberOfItemsInNumberArray = numbers.length;
		double average = numbersTotal / numberOfItemsInNumberArray;
		return average;			
	}
	
	public static double getHighest(double[]numbers) {
		double highestNumbers = numbers [0];
		
		for (int currentNumbersIndex = 0; currentNumbersIndex < numbers.length; currentNumbersIndex++ ) {
			if(numbers[currentNumbersIndex] > highestNumbers) {
				highestNumbers = numbers[currentNumbersIndex];
			}
		}
		return highestNumbers;
	}
	
	public static double getLowest(double[]numbers) {
		double lowestNumbers = numbers [0];
		
		for (int currentNumbersIndex = 0; currentNumbersIndex < numbers.length; currentNumbersIndex++ ) {
			if(numbers[currentNumbersIndex] > lowestNumbers) {
				lowestNumbers = numbers[currentNumbersIndex];
			}
		}
		
		return lowestNumbers;
		
	}
	
	public static void main(String[] args) {
		double [] numbers = {2, 3, 4, 5, 10 , 6, 10, 8, 2, 4};
		
		System.out.println("Total: " + getTotal(numbers) + "\n" +
							"Average: " + getAverage(numbers) + "\n" +
							"Highest: " + getHighest(numbers) + "\n" +
							"Lowest: " + getLowest(numbers));
		
	}
	

}
