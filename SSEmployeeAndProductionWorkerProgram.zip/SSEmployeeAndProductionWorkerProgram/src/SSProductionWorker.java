//Samantha Squirrel
//Java CSC 142 
//Chapter 9 Programming Exercise 1
//Assignment due 4-18-2019

public class SSProductionWorker extends SSEmployeeClass {
	private int employeeShift;
	private int employeeHoursWorked;
	private double employeePayRate;
	
	public SSProductionWorker(String name, String number, String hireDate, int shift, int payRate) {
		super(name, number, hireDate);
		employeeShift = shift;
		employeePayRate = payRate; 
	}
	
	public void setEmployeeShift(int shift) {
	    employeeShift = shift;
	}
	
	public void setEmployeePayRate(double payRate) {
		employeePayRate = payRate;
	}
	
	public int getEmployeeShift() {
	    return employeeShift;
	}

	public int getEmployeeHoursWorked() {
	    return employeeHoursWorked;
	}
	public double getPayRate() {
	    return employeePayRate;
	}

}
