//Samantha Squiurrel
//Java CSC 142 
//Chapter 9 Programming Exercise 1
//Assignment due 4-18-2019

public class SSEmployeeClass {
	private String employeeName;
	private String employeeNumber;
	private String employeeHireDate;
	
	public SSEmployeeClass(String name, String number, String hireDate) {
		employeeName = name;
		employeeNumber = number;
		employeeHireDate = hireDate;
	}
	
	public SSEmployeeClass() {
		employeeName = "";
		employeeNumber = "";
		employeeHireDate = "";
	}
	
	public void setName(String name) {
		employeeName = name; 
	}
	
	public void setNumber(String number) {
		employeeNumber = number;
	}
	
	public void setHireDate(String hireDate) {
		employeeHireDate = hireDate;
	}
	
	public String getEmployeeName() {
		return employeeName;
	}
	
	public String getEmployeeNumber() {
		return employeeNumber;
	}
	
	public String getEmployeeHireDate() {
		return employeeHireDate;
	}
	
	private boolean validEmployeeNumber(String number) {
		boolean status = true;
		
		if(number.length() != 5)
			status = false;
		else 
		{
			if ((!Character.isDigit(number.charAt(0))) ||
	        		 (!Character.isDigit(number.charAt(1))) ||
	                 (!Character.isDigit(number.charAt(2))) ||
	                 (number.charAt (3) != '-') ||
	                 (Character.toUpperCase(number.charAt(4)) < 'A')||
	                 (Character.toUpperCase(number.charAt(4)) > 'M'))
	                    status = false;
		}
		return status;
	}
	
	public String toString() {
		String str = "Employee name: " + employeeName + "\nEmployee Number:";
		
		if(employeeNumber == "")
			str += "Invalid employee number";
		else
			str  += employeeNumber;
		return
				str +=("\nEmployee Hire Date: " + employeeHireDate);
	}

}
