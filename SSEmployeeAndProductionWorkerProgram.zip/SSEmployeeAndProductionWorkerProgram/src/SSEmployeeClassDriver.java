//Samantha Squirrel
//Java CSC 142 
//Chapter 9 Programming Exercise 1
//Assignment due 4-18-2019

public class SSEmployeeClassDriver {
	
	public static void main(String[]args ) {
		
		SSEmployeeClass ee = new SSEmployeeClass("George Tanner", "123-A", "11/08/2019");
		System.out.println(ee);
		
		SSProductionWorker pw1 = new SSProductionWorker("Samantha Walker", "456-B", "1/24/2009", 2, 30);
		System.out.print(pw1);
		
	}

}
