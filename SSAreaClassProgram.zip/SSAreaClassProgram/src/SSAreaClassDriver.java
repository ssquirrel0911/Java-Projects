//Samantha Squirrel
//CSC 142 
//Assignment due 3-7-2019
//Chapter 6 Programming challenge 1 

//Area Class Driver

public class SSAreaClassDriver {
	
	public static void main(String[] args ) {
		
		//Area of a circle
		System.out.printf("The area of with a " + "radius of 10.0 is %6.2f\n", SSAreaClass.getArea(10.0));
	
		//Area of a rectangle
		System.out.printf("The area of a rectangle with a " + "length of 15 and a width of 25 is %6.2f\n",
			SSAreaClass.getArea(15, 25));
		
		//Area of a cylinder
		System.out.printf("The area of a cylinder with a " + "radius of 12.0 and a height " + "of 12.70 is %6.2f\n",
				SSAreaClass.getArea(12.0, 17.0));
	}
}

