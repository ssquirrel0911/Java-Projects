//Samantha Squirrel
//CSC 142 
//Assignment due 3-7-2019
//Chapter 6 Programming challenge 1 

//Area Class

public class SSAreaClass {
	//This method calculates the area of a circle
	public static double getArea(double radius) {
		return Math.PI * radius * radius;
	}
	
	//This method calculates the area of a rectangle
	public static double getArea(int length, int width) {
	return length * width;
	}
	
	//This method calculates the area of a circle
	public static double getArea(double radius, double height) {
		return Math.PI * radius * radius * height;
	}
}
