
public class RoomCarpetDimensionDriver {
	
	public static void main(String[] args) {
		double length;
		double width;
		RoomDimension dimension;
		RoomCarpet carpet;
		length = 12.0;
		width = 8.0;
		
		dimension = new RoomDimension(length, width);
		
		carpet = new RoomCarpet(dimension, 8.0);
		
		System.out.println(carpet);
	}

}
