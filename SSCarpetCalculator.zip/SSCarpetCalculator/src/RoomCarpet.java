import java.text.DecimalFormat;

public class RoomCarpet {
	private RoomDimension size;
	private double carpetCost;
	
	public RoomCarpet(RoomDimension dim, double cost) {
		this.size = size;	
		this.carpetCost = cost;
	}
	
	public double getTotalCost() {
		return carpetCost * size.getArea();
	}
	
	public String toString() {
		return ("The room dimensions: " + size + " , the carpest cost per square feet:  " 
	+ carpetCost + ", Total cost = $" + getTotalCost());
				
	}

}
