
public class RoomDimension {
	
	private double length;
	private double width;
	
	public RoomDimension(double len, double w) {
		this.length = len;
		this.width = w;
	}
	
	public double getLength() {
		return length;
	}
	
	public double getWidth() {
		return width;
	}
	
	public double getArea() {
		return length * width;
	}
	
	public String toString() {
		return ("The Dimensions of the room is; length = " + length + " width = " + width);
	}
	
	

}
