//Samantha Squirrel
//CSC 142
//Assignment due 4-2-2019
//Programming Exercise 6

public class SSDriverLicenseExam {
	private String[] correctAnswers = {"B", "D", "A", "A", "C", "A", "B", "A", "C", "D"};
	
	private String[] studentAnswers;
	private int numberOfQuestions = correctAnswers.length;
	
	public int totalCorrect() {
		int totalCorrectAnswers = 0;
		
		for(int index = 0; index < numberOfQuestions; index++) {
			if(correctAnswers[index].equalsIgnoreCase(studentAnswers[index])) {
				totalCorrectAnswers = totalCorrectAnswers + 1;
			}
		}
		return totalCorrectAnswers;
	}
	
	public int totalIncorrect() {
		int incorrectAnswers = 0;
		
		for(int index = 0; index < numberOfQuestions; index++) {
			if( !(correctAnswers[index].equalsIgnoreCase(studentAnswers[index]))) {
				incorrectAnswers = incorrectAnswers + 1;
			}
		}
		return incorrectAnswers;
	}
	
	public boolean passed() {
		int passingScore = 5;
		
		if(totalCorrect() >= passingScore) {
			return true;
		}
		
		return false;
		
	}
	
	public int[] questionsMissed() {
		int[] questionsMissedIn = new int [numberOfQuestions];
		int questionsMissedInIndex = 0;
		
		for( int index = 0; index < numberOfQuestions; index++) {
			if (!(correctAnswers[index].equalsIgnoreCase(studentAnswers[index]))) {
				questionsMissedIn[questionsMissedInIndex] = index + 1;
				questionsMissedInIndex++;
			}
		}
		
		return questionsMissedIn;
	}
	
	public SSDriverLicenseExam(String [] studentInGiven) {
		studentAnswers = studentInGiven;
	}

}
