//Samantha Squirrel
//CSC 142
//Assignment due 4-2-2019
//Programming Exercise 6
import java.util.Scanner;

public class SSDriverLicenseExamDriver {
	
	public static void answeredQuestions(String [] studentAnswers) {
		Scanner keyboard = new Scanner(System.in);
		
		for(int index = 0; index < studentAnswers.length; index++) {
			String studentResponse;
			
			System.out.println("What is the answer for question " + (index + 1));
			studentResponse = keyboard.nextLine();
			
			while(!studentResponse.equalsIgnoreCase("A") && !studentResponse.equalsIgnoreCase("B")  && 
					!studentResponse.equalsIgnoreCase("C") && !studentResponse.equalsIgnoreCase("D") ) {
				System.out.println("Invalid answer for question " + (index + 1));
				studentResponse = keyboard.nextLine();
				
			}
			studentAnswers[index] = studentResponse;
		}
	}
	public static void showResults(SSDriverLicenseExam driverExamObject) {
		System.out.println("You got " + driverExamObject.totalCorrect() + " correct answers and " + 
							driverExamObject.totalIncorrect() + " inccorect answers.");
		System.out.println("You missed questions " );
		for(int index = 0; index < driverExamObject.questionsMissed().length; index++) {
			if(driverExamObject.questionsMissed()[index] !=0) {
				System.out.println(driverExamObject.questionsMissed()[index] + " ");
			}
		}
		if(driverExamObject.passed()) {
			System.out.println("You passed");
		}else {
			System.out.println("You failed");
		}
	}
	public static void main(String [] args) {
		final int NUM_OF_QUESTIONS = 10;
		
		String [] studentAnswers = new String [NUM_OF_QUESTIONS];
		
		answeredQuestions(studentAnswers);
		
		SSDriverLicenseExam drivingTest = new SSDriverLicenseExam(studentAnswers);
		
		showResults(drivingTest);
	}

}
