//Samantha Squirrel
//CSC 142
//Chapter 8
//Programming Challenges 1
//Assingment due 4-11-2019

import java.util.Scanner;

public class SSBackwardStringClass {
	public static void main(String[] args) {
		String reverseWord;
		Scanner keyboard = new Scanner(System.in);
		
		
		System.out.print("Enter a word to reverse: ");
		reverseWord = keyboard.nextLine();
		
		char[] chr = new char[reverseWord.length()];
		
		System.out.println(reverseWord);
		
		int counter = 0;
		
		for(int i = reverseWord.length() - 1; i >= 0; i--) {
			System.out.println(reverseWord.charAt(i));
			
			chr[counter] = reverseWord.charAt(i);
			counter++;
		}
	}

}
