//Samantha Squirrel
//CSC 142 
//Assignment due 3-5-2019
//Chapter 5 Programming Exercise 11

//Deposit and Withdrawal Files Program

import java.io.*;
import java.util.Scanner;

public class SSDepositandWithdrawalFiles {
	public static void main(String[] args) throws IOException {
		
		SSSavingsAccountClass accountOne = new SSSavingsAccountClass (500);
		accountOne.setAnnualInterestRate(10);
		double totalInterestEarned = 0;
		
		File depositFile = new File("DeposistsFile.txt");
		File withdrawFile = new File("WithdrawalFile.txt");
		
		//User will be able to input deposits into text file
		Scanner inputFile = new Scanner(depositFile);
		
		while(inputFile.hasNext()) {
			accountOne.deposit(inputFile.nextDouble());
		}
		
		inputFile.close();
		
		//User will be able to input withdraws into text file
		inputFile = new Scanner (withdrawFile);
		
		while(inputFile.hasNext()) {
			accountOne.withdraw(inputFile.nextDouble());
		}
		
		inputFile.close();
		
		totalInterestEarned = accountOne.addToMonthlyInterest();
		
		System.out.printf("End balance: $%,.2f\nTotal interest earned: $%,.2f", accountOne.getBalance(), totalInterestEarned);
		
	
		
	}

}
