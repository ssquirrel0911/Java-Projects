
public class SSSavingsAccountClass {
	
	private double balance;
	private double annualInterestRate;


	
	public void withdraw(double amount) {
		balance -= amount;
	}
	
	public void deposit(double amount) {
		balance += amount;
	}
	
	
	public double addToMonthlyInterest() {
		double monthlyInterest = ((annualInterestRate / 12) * balance);
		
		balance += monthlyInterest;
		
		return monthlyInterest;
	}
	public void setAnnualInterestRate(double newerRate) {
		annualInterestRate = newerRate;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public SSSavingsAccountClass(double startBalance){
		balance = startBalance;
		annualInterestRate = 0;
	}

}
