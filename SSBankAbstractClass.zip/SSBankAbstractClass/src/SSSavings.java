//Samantha Squirrel
//CSC142
//Abstract class Programming exercise 2
//Assignment due 4-30-2019

public class SSSavings extends SSAccount {
	
	private double interestRate;
	
	public SSSavings(int accountNumber, double interest)
	{
		super(accountNumber);
		setInterestRate(interest);
	}
	
	public void setInterestRate(double interest)
	{
		interestRate = interest;
	}
	public double getInterestRate()
	{
		return interestRate;
	}
	
	public int getAccountNumber()
	{
		return accountNumber;
	}
	
	public double getBalance()
	{
		return balance;
	}
	
	public String getAccountInfo()
	{
		return("Savings Account Information\nAccount Number: " + getAccountNumber() + "\nBalance: " + getBalance() + "\nInterest Rate: " + getInterestRate() + "%");
}
	

}
