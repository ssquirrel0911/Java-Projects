//Samantha Squirrel
//CSC142
//Abstract class Programming exercise 2
//Assignment due 4-30-2019

public class SSAccountsDriver {
	public static void main(String[] args) {
		SSCheckings aCheckingAccount = new SSCheckings(1);
		SSSavings aSavingsAccount = new SSSavings(2, 1.6);
		
		System.out.println(aCheckingAccount);
		System.out.println(aSavingsAccount);
		}

}
