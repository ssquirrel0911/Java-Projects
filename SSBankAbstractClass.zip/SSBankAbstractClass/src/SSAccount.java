//Samantha Squirrel
//CSC142
//Abstract class Programming exercise 2
//Assignment due 4-30-2019

public abstract class SSAccount {
	protected int accountNumber;
	protected double balance;
	
	public SSAccount(int acctNum)
	{
		accountNumber = acctNum;
		setBalance(0.0);
	}
	
	public void setBalance(double b)
	{
		balance = b;
	}
	
	public int getAccountNumber() {
		return accountNumber;
	}
	
	public double getBalance() {
		return balance;
	}
	
public abstract String getAccountInfo();

}
