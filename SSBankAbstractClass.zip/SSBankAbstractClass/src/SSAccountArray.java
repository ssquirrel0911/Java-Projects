//Samantha Squirrel
//CSC142
//Abstract class Programming exercise 2
//Assignment due 4-30-2019

public class SSAccountArray {
	
	public static void main(String[] args)
	{
		SSAccount[] accountArray = new SSAccount[10];
		
		accountArray[0] = new SSCheckings(11);
		accountArray[1] = new SSCheckings(12);
		accountArray[2] = new SSCheckings(13);
		accountArray[3] = new SSCheckings(14);
		accountArray[4] = new SSCheckings(15);
		accountArray[5] = new SSSavings(21, 1.0);
		accountArray[6] = new SSSavings(22, 1.1);
		accountArray[7] = new SSSavings(23, 1.2);
		accountArray[8] = new SSSavings(24, 1.3);
		accountArray[9] = new SSSavings(25, 1.4);
		
		for(int i = 0; i < accountArray.length; ++i)
			System.out.println(accountArray[i].getAccountInfo() + "\n");
}

}
