//Samantha Squirrel
//CSC142
//Abstract class Programming exercise 2
//Assignment due 4-30-2019

public class SSCheckings {
	public SSCheckings(int accountNumber) {
		super(accountNumber);
	}
	
	public int getAccountNumber()
	{
		return accountNumber;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public String getAccountInfo() {
		return("Checking Account Information\nAcct Num: " + getAccountNumber() + "\nBalance: " + getBalance());
		}

}
